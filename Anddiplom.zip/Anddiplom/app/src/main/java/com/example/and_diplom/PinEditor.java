package com.example.and_diplom;

import android.content.SharedPreferences;

public class PinEditor implements Keystore{
    private SharedPreferences pinSharedPref;
    private static String PIN = "pin";
    private int pincode;

    @Override
    public boolean hasPin() {
        try {
            pincode = Integer.parseInt(pinSharedPref.getString(PIN, ""));
        } catch (Exception e){
            return false;
        }
        return true;
    }

    @Override
    public boolean checkPin(int pin) {
        if(pincode == pin){
            return true;
        }
        return false;
    }

    @Override
    public void saveNew(int pin) {
        SharedPreferences.Editor pinEditor = pinSharedPref.edit();
        pinEditor.putString(PIN, String.valueOf(pin));
        pinEditor.apply();

    }
}
