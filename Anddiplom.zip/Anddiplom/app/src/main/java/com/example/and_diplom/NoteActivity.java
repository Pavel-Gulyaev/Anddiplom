package com.example.and_diplom;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class NoteActivity extends AppCompatActivity {

    FloatingActionButton menu_btn;
    FloatingActionButton new_note_btn;
    PinEditor pinEditor = new PinEditor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        initViews();
    }
    private void initViews(){
        menu_btn = findViewById(R.id.menu_btn);
        new_note_btn = findViewById(R.id.new_note_btn);
        menu_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog menu = onCreateMenu();
                menu.show();

            }
        });

    }

    private Dialog onCreateMenu(){
        AlertDialog.Builder menuBuilder = new AlertDialog.Builder(NoteActivity.this);
        LayoutInflater inflater = NoteActivity.this.getLayoutInflater();
        menuBuilder.setView(inflater.inflate(R.layout.dialog_menu, null));
        menuBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        menuBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        return menuBuilder.create();
    }
}
